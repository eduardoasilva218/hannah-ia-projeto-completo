import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatMutation = trpc.chat.send.useMutation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Adicionar mensagem do usuário
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      isUser: true,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      // Obter histórico para contexto (últimas 10 mensagens)
      const history = messages.slice(-10).map(m => ({
        role: m.isUser ? "user" as const : "assistant" as const,
        content: m.text
      }));

      const response = await chatMutation.mutateAsync({
        message: input,
        history
      });

      const aiMessage: Message = {
        id: Date.now().toString(),
        text: response.text,
        isUser: false,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        text: "Desculpe, ocorreu um erro ao processar sua mensagem. Tente novamente.",
        isUser: false,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  // Função para renderizar texto com suporte básico a imagens Markdown
  const renderMessageContent = (text: string) => {
    const imgRegex = /!\[.*?\]\((.*?)\)/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = imgRegex.exec(text)) !== null) {
      // Adicionar texto antes da imagem
      if (match.index > lastIndex) {
        parts.push(<span key={`text-${match.index}`}>{text.substring(lastIndex, match.index)}</span>);
      }
      // Adicionar imagem
      parts.push(
        <div key={`img-${match.index}`} className="my-3 rounded-lg overflow-hidden border border-neutral-800 bg-neutral-900">
          <img 
            src={match[1]} 
            alt="Gerada pela HannaH" 
            className="w-full h-auto max-h-[400px] object-contain"
            onLoad={scrollToBottom}
          />
        </div>
      );
      lastIndex = imgRegex.lastIndex;
    }

    // Adicionar texto restante
    if (lastIndex < text.length) {
      parts.push(<span key="text-end">{text.substring(lastIndex)}</span>);
    }

    return parts.length > 0 ? parts : text;
  };

  // Bypass de autenticação para fins de teste local no ambiente Manus
  const isTestMode = true; 
  if (!isAuthenticated && !isTestMode) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Assistente IA</h1>
          <p className="text-gray-400 mb-8">
            Sua IA pessoal com acesso a internet e ferramentas avançadas
          </p>
          <a href={getLoginUrl()}>
            <Button className="bg-blue-600 hover:bg-blue-700">
              Entrar com Manus
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Header - Identidade da HannaH IA (Sem Orbe no Cabeçalho) */}
      <div className="bg-neutral-900 border-b border-neutral-800 px-6 py-5 flex justify-between items-center sticky top-0 z-10 backdrop-blur-md bg-opacity-90">
        <div className="flex items-center gap-3">
          {/* Texto Dinâmico (HannaH / Pensando...) com fonte Inter (estilo Manus) */}
          <div className="flex items-center">
            <p className="text-lg font-bold tracking-tight text-white leading-none font-inter">
              {loading ? (
                <span className="flex items-center">
                  Pensando<span className="animate-pulse">...</span>
                </span>
              ) : (
                "HannaH"
              )}
            </p>
          </div>
        </div>
        
        {/* Indicador de Status Compacto */}
        <div className="flex items-center gap-2 px-3 py-1 bg-neutral-800/50 rounded-full border border-neutral-700/50">
          <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
          <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Core Active</span>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="flex justify-center items-center h-full">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-white mb-2 font-inter">
                  Olá! Eu sou a HannaH
                </h2>
                <p className="text-gray-400">
                  Comece uma conversa digitando abaixo
                </p>
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex flex-col ${
                    message.isUser ? "items-end" : "items-start"
                  }`}
                >
                  {/* Nome da HannaH IA acima da resposta com fonte Inter */}
                  {!message.isUser && (
                    <div className="flex items-center gap-3 mb-1 px-4">
                      <p className="text-lg font-bold tracking-tight text-white leading-none font-inter">HannaH</p>
                    </div>
                  )}
                  
                  <div
                    className={`max-w-[85%] lg:max-w-md px-4 py-2 rounded-lg ${
                      message.isUser
                        ? "bg-blue-600 text-white shadow-md shadow-blue-900/20"
                        : "bg-transparent text-white border-none"
                    }`}
                  >
                    <div className={`text-sm leading-relaxed ${!message.isUser ? "font-medium" : ""}`}>
                      {renderMessageContent(message.text)}
                    </div>
                    <p
                      className={`text-[10px] mt-2 font-normal ${
                        message.isUser
                          ? "text-white opacity-80"
                          : "text-white opacity-60"
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              ))}
              {loading ? (
                <div className="flex justify-start">
                  <div className="bg-neutral-800/30 px-4 py-2 rounded-lg">
                    <div className="flex space-x-2">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-100"></div>
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-200"></div>
                    </div>
                  </div>
                </div>
              ) : (
                /* Indicador de Espera (Orbe Colorido Pulsante + Nome) - Versão Aprovada */
                messages.length > 0 && !messages[messages.length - 1].isUser && (
                  <div className="flex items-center gap-3 mt-6 mb-4 px-4 animate-fade-in">
                    <div className="flex items-center justify-center">
                      {/* Orbe com cores dinâmicas variadas e efeito de pulso aprovado */}
                      <span className="w-3 h-3 rounded-full shadow-[0_0_15px_rgba(255,255,255,0.5)] bg-gradient-to-tr from-green-400 via-blue-500 to-purple-600 bg-[length:200%_200%] animate-orb-pulse"></span>
                    </div>
                    <p className="text-lg font-bold tracking-tight text-white leading-none font-inter">HannaH</p>
                  </div>
                )
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-neutral-800 p-4 bg-neutral-900">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Mensagem..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !loading) {
                  handleSendMessage();
                }
              }}
              disabled={loading}
              className="flex-1 bg-neutral-800 text-white rounded-lg px-4 py-2 border border-neutral-700 focus:outline-none focus:border-blue-500 disabled:opacity-50"
            />
            <Button
              onClick={handleSendMessage}
              disabled={loading || !input.trim()}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? "..." : "Enviar"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
