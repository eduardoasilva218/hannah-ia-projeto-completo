/**
 * Sistema de Segurança Exclusiva para HannaH
 * Garante que apenas o proprietário tenha acesso ao aplicativo
 */

import { Request, Response, NextFunction } from 'express';

// Chave de acesso exclusiva (você pode mudar isso)
const EXCLUSIVE_ACCESS_KEY = process.env.HANNAH_ACCESS_KEY || 'hannah-exclusive-2026';

// Armazenar dispositivos autorizados em memória (em produção, usar banco de dados)
const authorizedDevices = new Set<string>();

/**
 * Gera um hash único do dispositivo baseado em user-agent e IP
 */
function generateDeviceHash(req: Request): string {
  const userAgent = req.headers['user-agent'] || 'unknown';
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  return `${userAgent}-${ip}`.substring(0, 50);
}

/**
 * Middleware de autenticação exclusiva
 */
export function exclusiveAccessMiddleware(req: Request, res: Response, next: NextFunction) {
  // Pegar a chave de acesso do header ou cookie
  const accessKey = req.headers['x-hannah-key'] || req.cookies?.hannah_key;
  const deviceHash = generateDeviceHash(req);

  // Se o dispositivo já foi autorizado, permitir
  if (authorizedDevices.has(deviceHash)) {
    return next();
  }

  // Se a chave correta foi fornecida, autorizar este dispositivo
  if (accessKey === EXCLUSIVE_ACCESS_KEY) {
    authorizedDevices.add(deviceHash);
    // Definir cookie para persistência
    res.cookie('hannah_key', EXCLUSIVE_ACCESS_KEY, {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 dias
    });
    return next();
  }

  // Caso contrário, retornar erro 401
  return res.status(401).json({
    error: 'Acesso não autorizado. Esta é uma instância exclusiva da HannaH.',
    message: 'Por favor, forneça a chave de acesso correta.'
  });
}

/**
 * Rota para autorizar um novo dispositivo
 */
export function authorizeDeviceRoute(req: Request, res: Response) {
  const { accessKey } = req.body;

  if (!accessKey) {
    return res.status(400).json({
      error: 'Chave de acesso não fornecida'
    });
  }

  if (accessKey !== EXCLUSIVE_ACCESS_KEY) {
    return res.status(401).json({
      error: 'Chave de acesso inválida'
    });
  }

  const deviceHash = generateDeviceHash(req);
  authorizedDevices.add(deviceHash);

  // Definir cookie
  res.cookie('hannah_key', EXCLUSIVE_ACCESS_KEY, {
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
    maxAge: 30 * 24 * 60 * 60 * 1000
  });

  return res.json({
    success: true,
    message: 'Dispositivo autorizado com sucesso!',
    deviceId: deviceHash.substring(0, 20)
  });
}

/**
 * Rota para revogar acesso de um dispositivo
 */
export function revokeDeviceRoute(req: Request, res: Response) {
  const deviceHash = generateDeviceHash(req);
  authorizedDevices.delete(deviceHash);

  res.clearCookie('hannah_key');

  return res.json({
    success: true,
    message: 'Acesso revogado com sucesso'
  });
}

/**
 * Rota para listar dispositivos autorizados
 */
export function listDevicesRoute(req: Request, res: Response) {
  return res.json({
    authorizedDevices: Array.from(authorizedDevices).map((device) => ({
      id: device.substring(0, 20),
      authorized: true
    }))
  });
}
