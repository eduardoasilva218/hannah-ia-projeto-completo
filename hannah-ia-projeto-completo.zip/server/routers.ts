import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { generateImage } from "./_core/imageGeneration";
import { transcribeAudio } from "./_core/voiceTranscription";
import { callDataApi } from "./_core/dataApi";
import { makeRequest as makeMapRequest } from "./_core/map";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  chat: router({
    send: publicProcedure
      .input(z.object({
        message: z.string().min(1),
        history: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string()
        })).optional()
      }))
      .mutation(async ({ input }) => {
        try {
          const today = new Date();
          const dateString = today.toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
          const timeString = today.toLocaleTimeString('pt-BR');

          // Lógica para detectar pedido de imagem
          const imageKeywords = ["gere uma imagem", "gerar imagem", "crie uma imagem", "criar imagem", "desenhe", "foto de"];
          const isImageRequest = imageKeywords.some(keyword => input.message.toLowerCase().includes(keyword));

          if (isImageRequest) {
            console.log("Detectado pedido de imagem:", input.message);
            const imageResult = await generateImage({ prompt: input.message });
            if (imageResult.url) {
              return {
                text: `Com certeza! Aqui está a imagem que você pediu:\n![Imagem Gerada](${imageResult.url})`
              };
            }
          }

          const systemPrompt = `Você é HannaH, a inteligência artificial principal. Inteligente, direta e amigável. 
Data de hoje: ${dateString}. Hora: ${timeString}. 
Você tem acesso a ferramentas de pesquisa, mapas, geração de imagem e transcrição de voz. 
Responda sempre em Português Brasileiro.`;

          const messages = [
            { role: "system" as const, content: systemPrompt },
            ...(input.history || []).map(h => ({ role: h.role as any, content: h.content })),
            { role: "user" as const, content: input.message }
          ];

          const result = await invokeLLM({ messages });
          const responseText = result.choices[0]?.message.content;
          
          return {
            text: typeof responseText === 'string' ? responseText : "Olá, eu sou a HannaH. Estou pronta para te ouvir!"
          };
        } catch (e) {
          console.error("HannaH Chat Error:", e);
          return { text: "HannaH aqui! Houve um erro de conexão, mas você pode tentar novamente." };
        }
      }),
  }),

  tools: router({
    generateImage: publicProcedure
      .input(z.object({ prompt: z.string() }))
      .mutation(async ({ input }) => {
        return await generateImage({ prompt: input.prompt });
      }),
    
    transcribe: publicProcedure
      .input(z.object({ audioUrl: z.string() }))
      .mutation(async ({ input }) => {
        return await transcribeAudio(input);
      }),

    search: publicProcedure
      .input(z.object({ query: z.string() }))
      .mutation(async ({ input }) => {
        return await callDataApi("web_search", { query: { q: input.query } });
      }),

    maps: publicProcedure
      .input(z.object({ endpoint: z.string(), params: z.record(z.any()) }))
      .mutation(async ({ input }) => {
        return await makeMapRequest(input.endpoint, input.params);
      }),
  }),
});

export type AppRouter = typeof appRouter;
