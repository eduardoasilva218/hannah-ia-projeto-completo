# HannaH - Assistente IA Inteligente

Um assistente de inteligência artificial moderno construído com React, TypeScript, tRPC e Express. O HannaH oferece uma interface de chat elegante com suporte a integração com APIs externas para geração de imagens, transcrição de voz e muito mais.

## 🚀 Características

- **Chat em Tempo Real**: Interface moderna e responsiva para conversar com a IA
- **Autenticação OAuth**: Sistema seguro de autenticação integrado com Manus
- **Geração de Imagens**: Crie imagens usando prompts de texto
- **Transcrição de Voz**: Converta áudio em texto com suporte a múltiplos idiomas
- **Integração com APIs**: Acesso a dados de terceiros e serviços externos
- **Google Maps Integration**: Utilize APIs do Google Maps para localização e rotas
- **LLM Avançado**: Suporte a modelos de linguagem como Gemini 2.5 Flash
- **Banco de Dados**: Armazenamento persistente com MySQL/TiDB via Drizzle ORM

## 📋 Pré-requisitos

- **Node.js**: v18 ou superior
- **pnpm**: v10 ou superior (gerenciador de pacotes)
- **MySQL**: v8 ou superior (para banco de dados)
- **Variáveis de Ambiente**: Configuradas no arquivo `.env`

## 🔧 Instalação e Configuração

### 1. Clonar e Instalar Dependências

```bash
# Extrair o arquivo do projeto
tar -xzf hannah-fixed.tar.gz
cd manus-clone

# Instalar dependências
pnpm install
```

### 2. Configurar Variáveis de Ambiente

Copie o arquivo `.env.example` para `.env` e configure com seus valores:

```bash
cp .env.example .env
```

**Variáveis Essenciais:**

| Variável | Descrição | Exemplo |
| :--- | :--- | :--- |
| `VITE_APP_ID` | ID da aplicação no Manus | `hannah-ai` |
| `JWT_SECRET` | Chave secreta para sessões | `seu-secret-super-seguro` |
| `DATABASE_URL` | URL de conexão MySQL | `mysql://user:pass@localhost:3306/hannah` |
| `OAUTH_SERVER_URL` | URL do servidor OAuth | `https://auth.manus.im` |
| `VITE_OAUTH_PORTAL_URL` | URL do portal OAuth | `https://auth.manus.im` |
| `BUILT_IN_FORGE_API_URL` | URL da API Forge | `https://forge.manus.im` |
| `BUILT_IN_FORGE_API_KEY` | Chave de API Forge | `sua-chave-api` |

### 3. Configurar Banco de Dados

```bash
# Gerar e executar migrações
pnpm db:push
```

## 🏃 Executando o Projeto

### Modo Desenvolvimento

```bash
pnpm dev
```

O servidor iniciará em `http://localhost:3000` com hot-reload ativado.

### Modo Produção

```bash
# Build
pnpm build

# Iniciar servidor
pnpm start
```

## 📁 Estrutura do Projeto

```
manus-clone/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Páginas da aplicação
│   │   ├── components/    # Componentes React
│   │   ├── hooks/         # Custom hooks
│   │   ├── contexts/      # Context API
│   │   └── lib/           # Utilitários
│   └── index.html         # Template HTML
├── server/                # Backend Express + tRPC
│   ├── _core/
│   │   ├── index.ts       # Ponto de entrada do servidor
│   │   ├── trpc.ts        # Configuração tRPC
│   │   ├── context.ts     # Contexto tRPC
│   │   ├── oauth.ts       # Fluxo OAuth
│   │   ├── llm.ts         # Integração com LLM
│   │   ├── imageGeneration.ts
│   │   ├── voiceTranscription.ts
│   │   └── ...
│   ├── db.ts              # Funções de banco de dados
│   ├── storage.ts         # Gerenciamento de armazenamento
│   └── routers.ts         # Definição de rotas tRPC
├── drizzle/               # Migrações e schema do banco
├── shared/                # Código compartilhado
└── package.json           # Dependências do projeto
```

## 🧪 Testando a Aplicação

### Verificar Tipos TypeScript

```bash
pnpm check
```

### Executar Testes

```bash
pnpm test
```

### Verificar Formatação

```bash
pnpm format
```

## 🔌 APIs Disponíveis

### Autenticação

- **GET** `/api/oauth/callback` - Callback do OAuth
- **GET** `/api/trpc/auth.me` - Obter usuário atual
- **POST** `/api/trpc/auth.logout` - Fazer logout

### Sistema

- **POST** `/api/trpc/system.health` - Verificar saúde da aplicação
- **POST** `/api/trpc/system.notifyOwner` - Notificar proprietário (admin)

## 🤖 Usando a IA

### Chat

A interface de chat está disponível em `http://localhost:3000` após login. Digite suas mensagens e a IA responderá.

### Geração de Imagens

```typescript
// Exemplo de uso no frontend
const { url } = await generateImage({
  prompt: "Uma paisagem montanhosa ao pôr do sol"
});
```

### Transcrição de Voz

```typescript
// Exemplo de uso no frontend
const result = await transcribeAudio({
  audioUrl: "https://example.com/audio.mp3",
  language: "pt"
});
```

## 🔐 Segurança

- **Autenticação**: OAuth 2.0 com Manus
- **Sessões**: JWT com expiração configurável
- **Cookies**: HttpOnly, SameSite=None para CORS
- **API Keys**: Armazenadas em variáveis de ambiente
- **CORS**: Configurado para aceitar requisições do frontend

## 🐛 Troubleshooting

### Porta 3000 já em uso

O servidor tentará automaticamente a próxima porta disponível (3001, 3002, etc.).

### Erro de conexão com banco de dados

Verifique se:
- MySQL está rodando
- `DATABASE_URL` está correto
- Credenciais de acesso estão válidas

### Erro de OAuth

Certifique-se de:
- `OAUTH_SERVER_URL` está configurado
- `VITE_APP_ID` é válido
- `JWT_SECRET` é uma string forte

### Erro de API Forge

Verifique:
- `BUILT_IN_FORGE_API_URL` está correto
- `BUILT_IN_FORGE_API_KEY` é válida

## 📚 Documentação Adicional

- [tRPC Documentation](https://trpc.io/)
- [React Documentation](https://react.dev/)
- [Express Documentation](https://expressjs.com/)
- [Drizzle ORM Documentation](https://orm.drizzle.team/)

## 📝 Licença

MIT

## 👥 Suporte

Para suporte e dúvidas, entre em contato com a equipe de desenvolvimento.
