CREATE TABLE `lotofacilDraws` (
	`id` int AUTO_INCREMENT NOT NULL,
	`drawNumber` int NOT NULL,
	`drawDate` timestamp NOT NULL,
	`numbers` varchar(255) NOT NULL,
	`prize` decimal(15,2),
	`prizeWinners` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lotofacilDraws_id` PRIMARY KEY(`id`),
	CONSTRAINT `lotofacilDraws_drawNumber_unique` UNIQUE(`drawNumber`)
);
--> statement-breakpoint
CREATE TABLE `lotteryPredictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`lotteryType` enum('lotofacil','megasena') NOT NULL,
	`predictedNumbers` varchar(255) NOT NULL,
	`strategy` varchar(255) NOT NULL,
	`confidence` decimal(5,2),
	`reasoning` longtext,
	`result` enum('pending','won','lost') DEFAULT 'pending',
	`actualNumbers` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lotteryPredictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lotteryStatistics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lotteryType` enum('lotofacil','megasena') NOT NULL,
	`totalDraws` int NOT NULL,
	`averageJackpot` decimal(15,2),
	`maxJackpot` decimal(15,2),
	`minJackpot` decimal(15,2),
	`mostFrequentNumber` int,
	`leastFrequentNumber` int,
	`averageOddNumbers` decimal(5,2),
	`averageEvenNumbers` decimal(5,2),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lotteryStatistics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lotteryStrategies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lotteryType` enum('lotofacil','megasena') NOT NULL,
	`strategyName` varchar(255) NOT NULL,
	`description` longtext NOT NULL,
	`methodology` longtext NOT NULL,
	`successRate` decimal(5,2),
	`recommendedNumbers` varchar(255),
	`rationale` longtext,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lotteryStrategies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lotteryTrends` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lotteryType` enum('lotofacil','megasena') NOT NULL,
	`trendType` enum('hot_numbers','cold_numbers','due_numbers','balanced') NOT NULL,
	`numbers` varchar(255) NOT NULL,
	`strength` decimal(5,2),
	`confidence` decimal(5,2),
	`analysis` longtext,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lotteryTrends_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `megasenaDraws` (
	`id` int AUTO_INCREMENT NOT NULL,
	`drawNumber` int NOT NULL,
	`drawDate` timestamp NOT NULL,
	`numbers` varchar(255) NOT NULL,
	`additionalNumbers` varchar(255),
	`prize` decimal(15,2),
	`prizeWinners` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `megasenaDraws_id` PRIMARY KEY(`id`),
	CONSTRAINT `megasenaDraws_drawNumber_unique` UNIQUE(`drawNumber`)
);
--> statement-breakpoint
CREATE TABLE `numberFrequency` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lotteryType` enum('lotofacil','megasena') NOT NULL,
	`number` int NOT NULL,
	`frequency` int NOT NULL DEFAULT 0,
	`lastDrawn` timestamp,
	`daysSinceLastDraw` int,
	`averageDaysBetweenDraws` decimal(10,2),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `numberFrequency_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `numberPatterns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lotteryType` enum('lotofacil','megasena') NOT NULL,
	`patternType` enum('pair','sequence','even_odd','prime') NOT NULL,
	`pattern` varchar(255) NOT NULL,
	`frequency` int NOT NULL DEFAULT 0,
	`probability` decimal(10,4),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `numberPatterns_id` PRIMARY KEY(`id`)
);
